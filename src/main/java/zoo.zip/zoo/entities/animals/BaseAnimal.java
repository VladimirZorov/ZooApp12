package zoo.entities.animals;

public abstract class BaseAnimal implements Animal{

    private String name;
    private String kind;
    private double kg;
    private double price;

    public BaseAnimal(String name, String kind, double kg, double price) {
        this.name = name;
        this.kind = kind;
        this.kg = kg;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getKg() {
        return kg;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void eat() {

    }
}
